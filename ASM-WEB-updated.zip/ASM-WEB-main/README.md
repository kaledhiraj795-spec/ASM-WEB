# ASM NextGen Technical Campus Website

## Run locally
Open `index.html` in a browser, or serve this folder with a local static web server.

## GitHub Pages
Publish the repository root; `index.html` is the homepage entry point. Keep file and folder names unchanged because GitHub Pages hosting is case-sensitive.

## Notes
- Navigation paths have been normalized to files included in this project.
- Contact form UI currently shows a client-side confirmation only; it does not send/store messages without a backend or form service.
- External font/icon/CDN resources require an internet connection.
